class ChassisConfig:
    def __init__(self, name):
        self.chassis_name = name
        self.have_system_config = False

    def reset_connection(self):
        self.have_system_config = False

class ChassisMgr:
    def __init__(self):
        self.chassis = {}

    def add_chassis(self, chassis_name):
        if chassis_name not in self.chassis:
            self.chassis[chassis_name] = ChassisConfig(chassis_name)

    def get_chassis(self, chassis_name):
        return self.chassis[chassis_name] if chassis_name in self.chassis else None
