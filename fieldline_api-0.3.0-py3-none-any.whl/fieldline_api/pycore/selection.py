import logging


def parse_selection(select_str, data_source):
    selections = {}
    select_groups = select_str.split(";")
    # logging.info("selection groups %s" % select_groups)
    for sg in select_groups:
        pairs = sg.split(":")
        # logging.info("pairs %s" % pairs)
        chassis_range = pairs[0]
        sensor_range = pairs[1]
        chassis_parse = parse_range_group(chassis_range)
        sensor_parse = parse_range_group(sensor_range)
        logging.info("chassis %s" % chassis_parse)
        logging.info("sensor %s" % sensor_parse)
        get_selections(selections, chassis_parse, sensor_parse, data_source)
    return selections


def get_selections(selections, chassis_parse, sensor_parse, data_source):
    sensors = data_source.get_sensors()
    for name, cid in data_source.chassis_name_to_id.items():
        if cid not in selections:
            selections[cid] = []
        if chassis_parse['all'] or cid in chassis_parse['list']:
            for s in sensors:
                if s.chassis_id == cid and (sensor_parse['all'] or s.sensor_id in sensor_parse['list']):
                    selections[cid].append(s.sensor_id)


def parse_range_group(range_str):
    ret = {'all': False, 'list': []}
    range_vals = range_str.split(",")
    for r in range_vals:
        # logging.info("range val %s" % r)
        p = parse_range_single(r)
        # logging.info("ret %s" % p)
        if p['all']:
            ret['all'] = True
        elif p['start'] is not None and p['end'] is not None:
            for i in range(p['start'], p['end'] + 1):
                ret['list'].append(i)
        elif p['single'] is not None:
            ret['list'].append(p['single'])
    return ret


def parse_range_single(range_str):
    ret = {'all': False, 'start': None, 'end': None, 'single': None}
    if range_str == "*":
        ret['all'] = True
    else:
        r = range_str.split('-')
        # logging.info("r %s" % r)
        if len(r) > 1:
            ret['start'] = int(r[0])
            ret['end'] = int(r[1])
        else:
            ret['single'] = int(r[0])
    return ret


