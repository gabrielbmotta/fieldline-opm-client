import threading
import zeroconf as zc
import socket
from collections import defaultdict
import logging
import json
from multiprocessing import Event
import queue
import time
import random

from pycore.interprocess_data import InterprocessDataPacketQueue
from pycore.data_source import DataSource
from pycore.network_client import NetworkClient
from pycore import net_protocol_pb2 as proto
from pycore import common
from pycore.chassis_mgr import ChassisMgr


def recursive_defaultdict():
    """
    defaultdict that supports an arbitrary number of levels
    """
    return defaultdict(recursive_defaultdict)


class NetworkDataSource(DataSource):
    PORT = 7777
    def __init__(self, interfaces, zeroconf_prefix, counter_lock, counter, hardware_state, developer_mode=False):
        DataSource.__init__(self, hardware_state)
        self.counter_lock = counter_lock
        self.counter = counter
        self.interfaces = interfaces
        self.zeroconf_prefix = zeroconf_prefix
        self.zeroconf = None
        self.shutting_down = False
        self.services = {}
        self.services_lock = threading.RLock()
        self.sensor_config = recursive_defaultdict()
        self._zeroconf_name_to_chassis_name = {}
        self._chassis_name_to_zeroconf_name = {}
        self.chassis_name_to_id = {}
        self.chassis_status = {}
        self.last_connected = common.read_chassis_config()
        self.closed_loop_expected = None
        self.waiting_on_closed_loop = True

        self.frame_q_lock = threading.Lock()
        self.frame_ready_condition = threading.Condition(self.frame_q_lock)
        self.reset_frame_buffer()
        self.frame_buffer = {}

        self.discovered_devices = {}
        self.available_devices = {}
        self.expect_device_reboot = {}
        self.update_chassis_version = {}
        self.num_expected_devices = 0
        self.prev_num_expected = 0
        self.startup_complete = False
        self.reconnect_list = []
        self.previously_connected = []
        self.waiting_on_reconnects = False
        self.manual_ips = common.get_user_pref('ip_list', [])
        self.update_connections = False

        self._developer_mode = developer_mode
        self._developer_mode_password = None
        self.stream_thread = None

        self.chassis_mgr = ChassisMgr()

    def __del__(self):
        self.shutdown(True)

    def reset_frame_buffer(self):
        with self.frame_q_lock:
            self.frame_q = {}
            self.frame_q_monitor = {}
            self.frames_syncd = False
            self.no_sync = True
            self.last_frame = 0
            self.frames_expected_dict = {}
            self.frame_reset_pending = False
            self.frame_delta = None
            self.sync_active = {}
            self.last_ts = {}
            self.log_sync_error = True
            self.channel_lookup = {}
            self.sensor_lookup = {}
            self.current_data_frames = {}

    def restart_zeroconf(self):
        if self.zeroconf:
            logging.info("Stopping zeroconf")
            self.zeroconf.close()
            self.zeroconf = None
        logging.info("Starting zeroconf")
        self._zeroconf_name_to_chassis_name = {}
        self.zeroconf = zc.Zeroconf(self.interfaces)
        self.browser = zc.ServiceBrowser(self.zeroconf, "_http._tcp.local.",
                                         handlers=[self.on_zeroconf_service_state_change])

    def set_developer_mode(self, value):
        super(NetworkDataSource, self).set_developer_mode(value)
        if not value:
            self.disable_chassis_developer_mode()

    def is_datatype_valid(self, sensor, data_type):
        if self._developer_mode:
            return True
        else:
            if sensor == 0:
                return data_type in common.CHASSIS_ACTIVE_REGISTERS.values()
            else:
                return data_type in common.ACTIVE_REGISTERS.values()

    def is_chassis_expected(self, chassis_name):
        return chassis_name in self.chassis_name_to_id

    def is_config_mismatch(self):
        with self.services_lock:
            total = []
            for chassis_name, svc in self.services.items():
                if svc.is_connected and chassis_name in self.discovered_devices:
                    total.append(self.discovered_devices[chassis_name]['total'])
            totals_match = all([t == self.num_expected_devices for t in total])
            ret = len(total) != self.num_expected_devices or not totals_match
            logging.info("config_mismatch totals: %s num_expected: %d ret: %s" % (total, self.num_expected_devices, ret))
            return ret

    def startup(self, cb=None):
        self.chassis_name_to_id = self.last_connected
        self.num_expected_devices = len(self.last_connected)
        self.prev_num_expected = self.num_expected_devices
        all_connected = True
        for name, chassis_id in self.last_connected.items():
            c = name.split(":")
            if cb:
                cb(f"Attempting connection to {c[0]}")
            connected = self.connect_req(c[0], int(c[1]))
            if not connected:
                all_connected = False
        if all_connected:
            for name, chassis_id in self.last_connected.items():
                c = name.split(":")
                if cb:
                    cb(f"Connecting to {c[0]}")
                self.connect_chassis(name)
                self.hardware_state.add_chassis(chassis_id)
        else:
            logging.info("Failure to connect to all previously connected devices")
        for name in self.manual_ips:
            device_name = "%s:%d" % (name, NetworkDataSource.PORT)
            if device_name not in self.available_devices:
                if cb:
                    cb(f"Attempting connection to {name}")
                self.connect_req(name, NetworkDataSource.PORT)
        startup_error = False
        for name, chassis_id in self.last_connected.items():
            if name not in self.discovered_devices or self.discovered_devices[name]['total'] != self.num_expected_devices:
                startup_error = True
        self.startup_complete = True
        if startup_error:
            if cb:
                cb(f"Connection failures, resuming startup")
            self.stop_services()
            # self.report_error("Startup config error")

    def start_monitor(self):
        self.monitor_thread = threading.Thread(target=self._monitor_thread)
        self.monitor_thread.start()
        self.restart_zeroconf()

    def get_chassis_names(self):
        return list(self.chassis_name_to_id.keys())

    def get_chassis_name_from_id(self, c_id):
        for name, chassis_id in self.chassis_name_to_id.items():
            if chassis_id == c_id:
                return name
        return None

    def get_chassis_serial(self, c_id):
        c_name = self.get_chassis_name_from_id(c_id)
        if c_name in self.discovered_devices and 'serial_short' in self.discovered_devices[c_name]:
            return self.discovered_devices[self.get_chassis_name_from_id(c_id)]['serial_short']
        else:
            return None

    def get_chassis_list(self):
        ret = []
        for ch in self.discovered_devices.keys():
            sp = ch.split(":")
            ret.append(sp[0])
        return ret

    @property
    def active_services(self):
        active_services = {}
        with self.services_lock:
            for chassis_name, v in self.services.items():
                if self.is_chassis_expected(chassis_name):
                    active_services[chassis_name] = v
        return active_services

    def get_available_device_info(self):
        available_devices = {}
        logging.info("AVAILBLE %s" % self.available_devices)
        with self.services_lock:
            for chassis_name in self.available_devices.keys():
                if chassis_name in self.services:
                    if self.services[chassis_name].is_connected:
                        available_devices[chassis_name] = self.discovered_devices[chassis_name]
                elif chassis_name in self.discovered_devices:
                    available_devices[chassis_name] = self.discovered_devices[chassis_name]
                if chassis_name in available_devices:
                    available_devices[chassis_name]['address'] = self.available_devices[chassis_name]['address']
                    available_devices[chassis_name]['port'] = self.available_devices[chassis_name]['port']
        return available_devices

    def disable_channel(self, chassis, sensor, data_type):
        logging.info("Disabling sensor %s %s %s" % (chassis, sensor, data_type))
        self.configure_sensor(chassis, sensor, data_type, 0)

    def configure_sensor(self, chassis, sensor, data_type, frequency, calibration=1.0):
        logging.info(f"Sensor configured: chassis={chassis} sensor={sensor}, data_type={data_type}, frequency={frequency} hz, calibration={calibration}")
        if not self.is_datatype_valid(sensor, int(data_type)):
            logging.warn(f"Data {data_type} is not valid")
            return
        self.sensor_config[chassis][sensor][data_type] = frequency
        chassis_id = self.chassis_name_to_id[chassis]
        active_before = self.hardware_state.has_active_channels(chassis_id)
        self.hardware_state.configure_channel(
            chassis_id,
            sensor,
            data_type,
            frequency,
            calibration
        )
        active_after = self.hardware_state.has_active_channels(chassis_id)
        if self.is_streaming and active_before == False and active_after == True:
            with self.services_lock:
                self.services[chassis].start_streaming()
        elif active_before == True and active_after == False:
            with self.services_lock:
                self.services[chassis].stop_streaming()
            with self.frame_q_lock:
                if chassis_id in self.frame_q:
                    logging.info("Chassis %d no longer has channels, removing from frame q" % chassis_id)
                    del self.frame_q[chassis_id]
                    self._stop_frame_q_monitor(chassis_id)

    def configure_sensor_list(self, chassis, sensor, channel_configs):
        channel_list = []
        for data_type, config in channel_configs.items():
            frequency, calibration = config
            self.configure_sensor(
                chassis=chassis,
                sensor=int(sensor),
                data_type=data_type,
                frequency=frequency,
                calibration=calibration
            )
            channel_list.append((int(sensor), data_type, frequency))
        chassis_id = self.chassis_name_to_id[chassis]
        sensor_name = "%02d:%02d" % (int(chassis_id), int(sensor))
        sensor_obj = self.get_sensor_from_name(sensor_name)

        for channel in sensor_obj.get_channels():
            if int(channel.data_index) not in channel_configs.keys():
                logging.info("NOT IN KEYS %s %s" % (channel.data_index, channel_configs.keys()))
                self.disable_channel(chassis, sensor, int(channel.data_index))
                channel_list.append((int(sensor), int(channel.data_index), 0))
        logging.info("channel lists: %s" % channel_list)

        with self.services_lock:
            if chassis in self.services:
                self.services[chassis].cmd_config_sensor_list(channel_list)

    def send_logic_module_command(self, chassis_id, sensor_id, data):
        chassis = self.get_chassis_name_from_id(chassis_id)
        self.send_raw_command(chassis, sensor_id, 260, data)

    def send_raw_command(self, chassis, sensor, address, data):
        if chassis not in self.active_services:
            logging.error(f"{chassis} is not a registered chassis, can not send raw command")
            return
        self.active_services[chassis].cmd_raw(sensor_num=sensor, register_address=address, data=data)

    def send_raw_command_by_chassis_id(self, chassis_id, sensor, address, data):
        chassis_name = None
        for c, c_id in self.chassis_name_to_id.items():
            if chassis_id == c_id:
                chassis_name = c
        if chassis_name is not None:
            self.send_raw_command(chassis_name, sensor, address, data)

    def send_logic_command(self, sensor_dict, command):
        self.sync_num_chassis(len(sensor_dict))
        for c,l in sensor_dict.items():
            chassis = self.get_chassis_name_from_id(c)
            if not chassis or chassis not in self.active_services:
                logging.error(f"{chassis} is not a registered chassis, can not send logic command")
                continue
            self.active_services[chassis].cmd_logic(l, command)

    def send_logic_interrupt_command(self, sensor_dict, command):
        self.sync_num_chassis(len(sensor_dict))
        for c,l in sensor_dict.items():
            chassis = self.get_chassis_name_from_id(c)
            if not chassis or chassis not in self.active_services:
                logging.error(f"{chassis} is not a registered chassis, can not send logic command")
                continue
            self.active_services[chassis].cmd_logic_interrupt(l, command)

    def send_one_time_read(self, chassis, sensor, address):
        if chassis not in self.active_services:
            logging.error(f"{chassis} is not a registered chassis, can not send one time read")
            return
        self.active_services[chassis].cmd_one_time_read(sensor_num=sensor, register_address=address)

    def save_sensor_config(self, filename):
        with open(filename, 'w') as f:
            json.dump(self.sensor_config, f)
        logging.info(f"Saved sensor configuration to {filename}")

    def load_sensor_config(self, filename):
        with open(filename, 'r') as f:
            sensor_config_from_file = json.load(f)

        channel_configs = {}
        for chassis, config in sensor_config_from_file.items():
            for sensor, dt_freq in config.items():
                for data_type, frequency in dt_freq.items():
                    self.configure_sensor(chassis, sensor, data_type, frequency)
                    if chassis not in channel_configs:
                        channel_configs[chassis] = []
                    channel_configs[chassis].append((int(sensor), int(data_type), int(frequency)))
        with self.services_lock:
            for chassis, channel_list in channel_configs.items():
                if chassis in self.services:
                    self.services[chassis].cmd_config_sensor_list(channel_list)

    def quick_sensor_config(self, selections, data_types, frequency, force=False):
        chassis_id_list = {}
        for svc in self.active_services.values():
            chassis_id_list[svc.chassis_id] = svc.chassis_name
        channel_configs = {}
        for chassis_id, sensor_list in selections.items():
            for sensor_id in sensor_list:
                s = self.get_sensor(chassis_id, sensor_id)
                if s.present and ((frequency > 0 and s.zerod) or (frequency == 0) or force):
                    for data_type in data_types:
                        self.configure_sensor(chassis_id_list[chassis_id], sensor_id, data_type, frequency)
                        if chassis_id_list[chassis_id] not in channel_configs:
                            channel_configs[chassis_id_list[chassis_id]] = []
                        channel_configs[chassis_id_list[chassis_id]].append((sensor_id, data_type, frequency))
        # logging.info("quick sensor configs: %s" % channel_configs)
        with self.services_lock:
            for chassis, channel_list in channel_configs.items():
                if chassis in self.services:
                    self.services[chassis].cmd_config_sensor_list(channel_list)

    def send_update_command(self, uri):
        self.update_chassis_version = {}
        for chassis_name, chassis in self.active_services.items():
            self.update_chassis_version[chassis_name] = None
            self.expect_device_reboot[chassis_name] = self.discovered_devices[chassis_name]
            logging.info("Before update properties for %s: %s" % (chassis_name, self.discovered_devices[chassis_name]))
            if 'zeroconf' not in self.discovered_devices[chassis_name]:
                logging.info("Waiting for %s to update" % chassis_name)
            chassis.cmd_update(uri)

    def verify_post_update(self):
        ret = True
        vals_to_check = ['num', 'total', 'master', 'serial']
        for chassis_name, prop in self.expect_device_reboot.items():
            chassis_ok = True
            if chassis_name not in self.discovered_devices:
                chassis_ok = False
            else:
                for v in vals_to_check:
                    if prop[v] != self.discovered_devices[chassis_name][v]:
                        logging.error("chassis %s current val for %s of %s does not match original %s" % (chassis_name, v, prop[v], self.discovered_devices[chassis_name][v]))
                        chassis_ok = False
            if not chassis_ok:
                ret = False
                logging.error("verify update failed for chassis %s" % chassis_name)
        return ret

    def send_commit_command(self):
        self.update_chassis_version = {}
        for chassis_name, chassis in self.active_services.items():
            chassis.cmd_commit()

    def complete_update(self):
        for chassis_name, chassis in self.active_services.items():
            del self.expect_device_reboot[chassis_name]

    def send_reboot_command(self):
        for _, chassis in self.active_services.items():
            chassis.cmd_reboot()

    def send_password(self, password):
        self._developer_mode_password = password
        for _, chassis in self.active_services.items():
            chassis.cmd_send_password(password)

    def send_sensor_config_req(self):
        for _, chassis in self.active_services.items():
            chassis.cmd_sensor_config_req()

    def disable_chassis_developer_mode(self):
        for _, chassis in self.active_services.items():
            chassis.cmd_disable_developer_mode()

    def get_chassis_version(self, chassis_id):
        for c_name, c_id in self.chassis_name_to_id.items():
            if chassis_id == c_id and c_name in self.discovered_devices:
                return self.discovered_devices[c_name]['version']
        return None

    def get_update_info(self):
        ret = [None for i in range(len(self.chassis_name_to_id))]
        for chassis_name, chassis_id in self.chassis_name_to_id.items():
            version = self.discovered_devices[chassis_name]['version']
            ret[chassis_id] = (chassis_name, version)
        return ret

    def all_versions_equal(self):
        if len(self.chassis_name_to_id) == 0:
            return True
        else:
            first_version = None
            for chassis_name, chassis_id in self.chassis_name_to_id.items():
                if chassis_name in self.expect_device_reboot:
                    continue
                v = self.discovered_devices[chassis_name]['version']
                if not first_version:
                    first_version = v
                elif first_version != v:
                    return False
        return True

    def num_connections(self):
        with self.services_lock:
            return len(self.services)

    def stop_services(self, chassis_list=None):
        logging.info("Stopping services %s" % chassis_list)
        with self.services_lock:
            if chassis_list is None:
                chassis_list = list(self.services.keys())
            for svc in chassis_list:
                self.service_disconnect(self.services[svc])
                self.services[svc].shutdown()
            for svc in chassis_list:
                self.services[svc].wait()
                chassis_id = self.services[svc].chassis_id
                del self.services[svc]
                self.hardware_state.remove_chassis(chassis_id)
        logging.info("Services are stopped")

    def shutdown(self, block=False):
        logging.info("Shutdown start")
        self.shutting_down = True
        self.stop()
        logging.info("Shutdown stop done")
        self.stop_services()
        logging.info("Shutdown stop_services done")

        if self.zeroconf is not None:
            if block:
                logging.info("Waiting for zeroconf to close...")
                self.zeroconf.close()
                logging.info("closed")
            else:
                t = threading.Thread(target=self.zeroconf.close)
                t.daemon = True
                t.start()

    def reset_chassis(self, chassis):
        self.active_services[chassis].cmd_reset()

    def ident_chassis(self, chassis, is_on):
        with self.services_lock:
            if chassis in self.services.keys():
                self.services[chassis].cmd_ident(is_on)
            elif chassis in self.discovered_devices.keys():
                logging.info("Chassis %s ident %s" % (chassis, is_on))
                chassis_properties = self.discovered_devices[chassis]
                NetworkClient.send_ident_request(is_on, chassis_properties['address'], chassis_properties['port'])
            else:
                logging.info("ident_chassis unable to find %s" % chassis)

    def attempt_connections(self, chassis_list):
        if chassis_list:
            self.waiting_on_closed_loop = True
            self.closed_loop_expected = None
            logging.info("Attempting connections: %s" % chassis_list)
            for c in chassis_list:
                self.connect_req(c)
            logging.info("Attempting connections complete")

    def connect_req(self, chassis, port=7777):
        chassis_name = "%s:%d" % (chassis, port)
        connected = False
        with self.services_lock:
            if chassis_name in self.services.keys():
                logging.info("Already connected to chassis: %s" % chassis)
            else:
                if chassis_name not in self.available_devices:
                    logging.info("Chassis %s not found in available devices" % chassis_name)
                    self.available_devices[chassis_name] = {}
                    device_properties = self.available_devices[chassis_name]
                    device_properties['address'] = chassis
                    device_properties['port'] = port
                    device_properties['connected'] = False
                logging.info("Attempting connect req to %s" % chassis)
                ret = NetworkClient.send_connect_req(chassis, port)
                if ret is not None:
                    connected = True
                    self.update_state(ret)
                    self.handle_chassis_added(chassis_name)
                logging.info("Connect req to %s: %s" % (chassis_name, ("Success" if ret is not None else "Failed")))
        return connected

    def connect_chassis_list(self, chassis_name_to_id):
        self.chassis_name_to_id = chassis_name_to_id
        self.last_connected = chassis_name_to_id
        disconnect_list = []
        with self.services_lock:
            for chassis_name in self.services.keys():
                if chassis_name not in self.chassis_name_to_id:
                    disconnect_list.append(chassis_name)
                    self.previously_connected.append(chassis_name)
            self.stop_services(chassis_list=disconnect_list)
            self.hardware_state.clear()
            self._handle_chassis_connections(0, 0)
            self.waiting_on_reconnects = True
            self.chassis_status = {}
            for chassis_name, chassis_id in chassis_name_to_id.items():
                self.hardware_state.add_chassis(chassis_id)
                self.chassis_status[chassis_name] = None
                if chassis_name in self.services:
                    self.services[chassis_name].chassis_id = self.chassis_name_to_id[chassis_name]
                    self.reconnect_list.append(chassis_name)
                    self.services[chassis_name].force_reconnect()
                else:
                    self.connect_chassis(chassis_name)
            self.num_expected_devices = len(self.chassis_name_to_id)
            self.prev_num_expected = self.num_expected_devices
        self.restart_zeroconf()

    def connect_chassis(self, chassis_name):
        if chassis_name in self.available_devices.keys():
            if chassis_name is None:
                logging.error("Trying to connect to chassis with None name")
                return
            elif not self.is_chassis_expected(chassis_name):
                logging.error(f"{chassis_name} is NOT expected, skipping")
            chassis_properties = self.available_devices[chassis_name]
            name = "Fieldline-%s-%d" % (chassis_properties['address'], chassis_properties['port'])
            name += "-%s" % str(random.randint(1000,9999))
            logging.info("Connecting to device: %s queue: %s" % (chassis_name, name))

            data_queue = InterprocessDataPacketQueue(name, True, chassis_id=self.chassis_name_to_id[chassis_name])
            new_service = NetworkClient(
                address=chassis_properties['address'],
                port=chassis_properties['port'],
                status_callback=self.update_state,
                raw_cmd_resp_callback=self._report_raw_cmd_resp,
                data_queue=data_queue,
                password_callback=self.password_callback,
                logger=logging,
                streaming_event=Event(),
                shutdown_event=Event(),
                done_event=Event()
            )
            new_service.chassis_name = chassis_name
            self.chassis_mgr.add_chassis(chassis_name)
            self.add_service(new_service)

    def on_zeroconf_service_state_change(self, zeroconf, service_type, name, state_change):
        if not name.startswith('%sFieldline' % self.zeroconf_prefix):
            return
        if self.shutting_down:
            logging.warn("Ignoring state change.. shutting down")
            return

        # logging.info("ZeroConf discovery reports service %s of type %s %s" % (name, service_type, state_change))

        if state_change == zc.ServiceStateChange.Added:
            info = zeroconf.get_service_info(service_type, name)
            chassis_name = None
            properties = {}
            if info.properties:
                logging.info("PROPERTIES ARE: ")
                for key, value in info.properties.items():
                    try:
                        key = key.decode("utf-8")
                        value = value.decode("utf-8")
                    except Exception:
                        continue
                    logging.info("key %s val %s" % (key, value))
                    if key == "name":
                        chassis_name = value
                    else:
                        properties[key] = value
            use_addr = None
            if len(info.addresses) == 1:
                use_addr = info.addresses[0]
            elif len(info.addresses) > 1:
                logging.info("Multiple addresses in info: %s" % info.addresses)
                use_addr = info.addresses[0]
            else:
                logging.error("No address found in info: %s" % info)
                return

            host, port = socket.inet_ntoa(use_addr), int(info.port)
            properties['address'] = host
            properties['port'] = port
            properties['zeroconf'] = name
            properties['closed_loop'] = None
            properties['num'] = int(properties['num'])
            properties['total'] = int(properties['total'])
            chassis_name = "%s:%d" % (host, port)
            if not properties['serial'].endswith('17') or not properties['master'].endswith('17'):
                logging.error("chassis %s invalid serial: %s master: %s" % (chassis_name, properties['serial'], properties['master']))
                return
            if chassis_name not in self.available_devices or 'msgversion' not in properties or chassis_name in self.previously_connected:
                if chassis_name in self.previously_connected:
                    logging.info(f"chassis {chassis_name} was previously connected")
                    self.previously_connected.remove(chassis_name)
                self.available_devices[chassis_name] = {}
                device_properties = self.available_devices[chassis_name]
                device_properties['address'] = host
                device_properties['port'] = port
                device_properties['connected'] = False
                device_properties['zeroconf'] = name
                if 'msgversion' not in properties:
                    logging.info("Old type device %s" % host)
                    self.discovered_devices[chassis_name] = properties
                elif chassis_name not in self.discovered_devices:
                    connected = self.connect_req(host, port=port)
                    if not connected:
                        logging.error("chassis %s unable to connect" % chassis_name)
                        self.discovered_devices[chassis_name] = properties
                        self.handle_chassis_added(chassis_name)
                return

    def handle_chassis_added(self, chassis_name):
        pass

    def handle_chassis_removed(self, chassis_name):
        pass

    def is_chassis_configured(self, chassis_name):
        with self.services_lock:
            return self.services[chassis_name].chassis_name != 'unknown' and \
                self.services[chassis_name].chassis_name in self.chassis_name_to_id

    def reset_connections(self, reason):
        self.restart_zeroconf()
        self._handle_chassis_disconnect(reason)

    def report_error(self, error_msg):
        if self.startup_complete and not self.waiting_on_reconnects:
            self._handle_device_error(error_msg)

    def _monitor_thread(self):
        num_connected = 0
        logging.info("Start monitor thread")
        while not self.shutting_down:
            total_samples_available = 0
            total_samples = []
            free_memory = []
            prev_connected = num_connected
            num_connected = 0
            with self.services_lock:
                for i, (name, svc) in enumerate(self.services.items()):
                    svc_connected = svc.is_connected
                    # logging.info(f"chassis {name} connected: {svc_connected}")
                    if not svc_connected:
                        if self.available_devices[name]['connected']:
                            self.available_devices[name]['connected'] = False
                            if name in self.discovered_devices and name not in self.reconnect_list:
                                self.previously_connected.append(name)
                                del self.discovered_devices[name]
                            logging.info(f"Chassis {name} is disconnected")
                            self.service_disconnect(svc)
                            if name not in self.expect_device_reboot not in self.reconnect_list:
                                self.report_error("Chassis disconnected")
                            if name in self.reconnect_list:
                                self.reconnect_list.remove(name)
                            self.waiting_on_closed_loop = True
                            self.closed_loop_expected = False
                    else:
                        if name in self.discovered_devices:
                            num_connected += 1
                        if not self.available_devices[name]['connected']:
                            self.available_devices[name]['connected'] =  True
                            logging.info(f"Chassis {name} is connected")
                            self.configure_service(svc)
                    #total_samples_available += self.services[name].num_samples_available()
                    total_samples.append(svc.num_samples_available())
                    free_memory.append(self.services[name].available_data_buf())
                if prev_connected != num_connected or self.prev_num_expected != self.num_expected_devices or self.update_connections:
                    if num_connected == self.num_expected_devices:
                        self.waiting_on_reconnects = False
                    self.prev_num_expected = self.num_expected_devices
                    self._handle_chassis_connections(num_connected, self.num_expected_devices)
                    self.update_connections = False
                if len(free_memory):
                    total_samples_available = sum(total_samples)
                    if total_samples_available > 1000:
                        logging.info("SAMPLES %s" % total_samples)
                    avg_samples_per_chassis = total_samples_available / len(self.services) if len(self.services) else 0
                    self._report_data_underrun(int(avg_samples_per_chassis), min(free_memory))
            time.sleep(1)


    def password_callback(self, chassis_name, msg):
        if msg.dev_mode.enable:
            if msg.dev_mode.valid:
                self._report_password_response(chassis_name, True)
            else:
                self._report_password_response(chassis_name, False)

    def update_state(self, msg=None):
        if msg is not None:
            msg_chassis_id = None
            chassis_name = msg.chassis_name
            msg_chassis_id = None
            if chassis_name in self.chassis_name_to_id:
                msg_chassis_id = self.chassis_name_to_id[chassis_name]
            self._report_chassis_status(chassis_name, msg.status)
            if msg.HasField('system_status'):
                # logging.info("SYSTEM STATUS: %s" % msg)
                prev_status = None
                if chassis_name in self.discovered_devices:
                    prev_status = self.discovered_devices.pop(chassis_name)
                self.discovered_devices[chassis_name] = {}
                d = self.discovered_devices[chassis_name]
                if prev_status and prev_status['num'] != msg.system_status.num:
                    logging.info("Chassis %s num prev: %d after: %d" % (chassis_name, prev_status['num'], msg.system_status.num))
                d['num'] = msg.system_status.num
                if prev_status and prev_status['total'] != msg.system_status.total:
                    logging.info("Chassis %s total prev: %d after: %d" % (chassis_name, prev_status['total'], msg.system_status.total))
                d['total'] = msg.system_status.total
                if chassis_name in self.last_connected and chassis_name not in self.expect_device_reboot and d['total'] != self.num_expected_devices:
                    logging.info("Chassis %s number of expected devices updated to: %d" % (chassis_name, d['total']))
                    self.report_error("Chassis config mismatch")
                if prev_status and prev_status['version'] != msg.system_status.version:
                    logging.info("Chassis %s version prev: %s after: %s" % (chassis_name, prev_status['version'], msg.system_status.version))
                d['version'] = msg.system_status.version
                if chassis_name in self.update_chassis_version:
                    self.update_chassis_version[chassis_name] = d['version']
                if prev_status and prev_status['master'] != msg.system_status.master:
                    logging.info("Chassis %s master prev: %s after: %s" % (chassis_name, prev_status['master'], msg.system_status.master))
                d['master'] = msg.system_status.master
                if prev_status and prev_status['serial'] != msg.system_status.serial:
                    logging.info("Chassis %s serial prev: %s after: %s" % (chassis_name, prev_status['serial'], msg.system_status.serial))
                d['serial'] = msg.system_status.serial
                if msg.system_status.HasField('serial_short'):
                    d['serial_short'] = msg.system_status.serial_short
                d['address'] = self.available_devices[chassis_name]['address']
                d['port'] = self.available_devices[chassis_name]['port']
                if prev_status is not None and 'closed_loop' in prev_status:
                    d['closed_loop'] = prev_status['closed_loop']
                else:
                    d['closed_loop'] = None
                if not self.is_config_mismatch():
                    self.report_error('')
                    self.update_connections = True
            if msg.HasField('chassis_status'):
                if msg.chassis_status.HasField('closed_loop') and chassis_name in self.discovered_devices:
                    self.discovered_devices[chassis_name]['closed_loop'] = msg.chassis_status.closed_loop
                    self.check_closed_loop()
            if msg.HasField('status'):
                self.chassis_status[chassis_name] = msg.status
            if len(msg.sensor_led) > 0:
                for s in self.get_sensors():
                    for sc in msg.sensor_led:
                        if sc.sensor_id == s.sensor_id and msg_chassis_id == s.chassis_id:
                            current_color = s.get_color()
                            current_blink = s.get_blink_state()
                            s.set_color(sc.color)
                            s.set_blink_state(sc.blink_state)
                            s.zerod = (sc.color == 6 and sc.blink_state == 1)
                            if current_color != sc.color or current_blink != sc.blink_state:
                                self._handle_blink_state_changed(s.chassis_id, s.sensor_id, sc.color, sc.blink_state)
                self._report_sensor_status_changed()
            if len(msg.sensor_config) > 0:
                channel_list = []
                for sc in msg.sensor_config:
                    if sc.HasField("calibration"):
                        calibration = sc.calibration
                    else:
                        calibration = 1.0
                    channel_list.append({'chassis_id': msg_chassis_id,
                                         'sensor_id': sc.sensor,
                                         'data_type': sc.datatype,
                                         'frequency': sc.freq,
                                         'calibration': calibration
                                        })
                self.hardware_state.configure_channel_list(msg_chassis_id, channel_list)
            if len(msg.sensor_status) > 0:
                for s in self.get_sensors():
                    for sc in msg.sensor_status:
                        if sc.sensor_id == s.sensor_id and msg_chassis_id == s.chassis_id:
                            if s.present != sc.sensor_connected:
                                logging.info("Sensor [%d:%d] connected changed to %s" % (s.chassis_id, sc.sensor_id, sc.sensor_connected))
                            s.present = sc.sensor_connected
                            s.card_serial = sc.sensor_card_serial_num
                            if sc.HasField('sensor_serial_num'):
                                s.sensor_serial = sc.sensor_serial_num
                            else:
                                s.sensor_serial = None
                self._report_sensor_status_changed()
            if len(msg.sensor_field) > 0:
                for s in self.get_sensors():
                    for sc in msg.sensor_field:
                        if sc.sensor_id == s.sensor_id and msg_chassis_id == s.chassis_id:
                            # logging.info("Updating fields chassis: %d sensor: %d x: %d y: %d z: %d" % (s.chassis_id, s.sensor_id, sc.field_x, sc.field_y, sc.field_z))
                            field_x = sc.field_x if sc.HasField('field_x') else None
                            field_y = sc.field_y if sc.HasField('field_y') else None
                            field_z = sc.field_z if sc.HasField('field_z') else None
                            s.set_fields(field_x, field_y, field_z)
                self._report_sensor_status_changed()
            if len(msg.sensor_state) > 0:
                for sc in msg.sensor_state:
                    s = self.get_sensor(msg_chassis_id, sc.sensor_id)
                    s.sensor_state = sc.state
                    s.sensor_error = None
                    logging.debug("Got SENSOR_STATE %d %s" % (sc.sensor_id, proto.SensorState.EnumStateType.Name(sc.state)))
                    if sc.HasField('error_flags'):
                        s.sensor_error = sc.error_flags
                        self._report_sensor_error(chassis_name, sc.sensor_id, sc.error_flags)
            if msg.HasField('progress') and msg.HasField('progress_msg'):
                self._report_update_progress(chassis_name, msg.progress, msg.type, msg.progress_msg)
            if msg.type == proto.StatusPacket.COMPLETE_SYSTEM_STATUS:
                self.chassis_mgr.get_chassis(chassis_name).have_system_config = True

    def add_service(self, svc):
        with self.services_lock:
            svc.chassis_id = self.chassis_name_to_id[svc.chassis_name]
            self.services[svc.chassis_name] = svc
            svc.start()

    def configure_service(self, svc):
        with self.services_lock:
            if self._developer_mode_password:
                svc.cmd_send_password(self._developer_mode_password)
            if self.is_streaming:
                # If the gui is already streaming send the start cmd to the new chassis
                svc.start_streaming()
            self._report_chassis_connection_change(svc.chassis_id, True)

    def service_disconnect(self, svc):
        chassis_id = svc.chassis_id
        self.chassis_mgr.get_chassis(svc.chassis_name).reset_connection()
        with self.frame_q_lock:
            if chassis_id in self.frame_q:
                del self.frame_q[chassis_id]
                self._stop_frame_q_monitor(chassis_id)
        self._report_chassis_connection_change(chassis_id, False)

    # frame_q_lock should be held before calling this
    def _stop_frame_q_monitor(self, chassis_id):
        if chassis_id in self.frame_q_monitor:
            self.frame_q_monitor[chassis_id][1].set()
            self.frame_q_monitor[chassis_id][0].join()
            del self.frame_q_monitor[chassis_id]
        else:
            logging.warning(f"chassis: {chassis_id} not found in frame_q_monitor")

    def _monitor_queue(self, chassis_id, data_queue, exit_event, continue_event):
        logging.info(f"starting monitor queue thread for chassis_id: %d" % chassis_id)
        channel_cache = {}
        sensor_cache = {}
        ts_delta = None
        t1 = None
        iterations = 0
        while not exit_event.is_set():
            if not continue_event.wait(0.1):
                continue
            try:
                timestamp,data = data_queue.get(block=True, timeout=0.5, data=self.current_data_frames if self.frames_syncd else None)
            except queue.Empty:
                continue
            with self.frame_ready_condition:
                continue_event.clear()
                if t1 is None:
                    t1 = time.time()

                self.frame_q[chassis_id] = timestamp
                if ts_delta is None and self.last_ts[chassis_id] is not None and self.last_ts[chassis_id] < timestamp:
                    ts_delta = timestamp - self.last_ts[chassis_id]
                    logging.info(f"chassis {chassis_id} ts_delta is {ts_delta}")
                if timestamp == 1:
                    # timestamp is unsigned 32 bit counter
                    if self.last_ts[chassis_id] is not None and ts_delta is not None and self.last_ts[chassis_id] + ts_delta > 0xFFFFFFFF:
                        logging.info(f"chassis {chassis_id} timestamp rollover")
                    else:
                        self.no_sync = False
                        if chassis_id not in self.sync_active:
                            logging.info("chassis %d sync detected ts %d" % (chassis_id, timestamp))
                            self.sync_active[chassis_id] = True
                            self.frame_reset_pending = True
                            self.frames_syncd = False
                        else:
                            logging.info("chassis %d sync detected while active ts %d" % (chassis_id, timestamp))
                elif self.last_ts[chassis_id] is not None:
                    if timestamp < self.last_ts[chassis_id]:
                        logging.warning("chassis [%d] new ts: %d less than last ts: %d" % (chassis_id, timestamp, self.last_ts[chassis_id]))
                self.last_ts[chassis_id] = timestamp

                if self.frames_syncd:
                    self.current_data_frames = self.current_data_frames | data

                iterations += 1
                if time.time() - t1 >= 60.0:
                    logging.info("chassis [%d] avg %d iterations/sec" % (chassis_id, int(iterations/60)))
                    iterations = 0
                    t1 = None

                if all([q is not None for q in self.frame_q.values()]):
                    self.frame_ready_condition.notify()
        logging.info(f"exiting monitor queue thread for chassis_id: %d" % chassis_id)


    def _check_data_frames(self):
        with self.frame_q_lock:
            for svc in self.active_services.values():
                chassis_id = svc.chassis_id
                if chassis_id not in self.frame_q:
                    logging.info("New chassis_id %d for frame data" % chassis_id)
                    self.frame_q[chassis_id] = None
                    self.last_ts[chassis_id] = None
                    exit_event = threading.Event()
                    continue_event = threading.Event()
                    continue_event.set()
                    t = threading.Thread(target=self._monitor_queue,args=(chassis_id, svc.data_queue, exit_event, continue_event,))
                    self.frame_q_monitor[chassis_id] = (t, exit_event, continue_event)
                    if len(self.frame_q) > 1:
                        self.frames_syncd = False
                        self.frame_reset_pending = True
                        self.sync_active[chassis_id] = True
                    else:
                        self.frames_syncd = True
                    t.start()


    def _build_frame(self):
        out_data = None
        ts_list = []
        for q in self.frame_q.values():
            if q:
                ts_list.append(q)
            else:
                return None
        # logging.info("tslist %s" % (ts_list))

        chassis_to_send = []
        if self.no_sync:
            if not all(e == ts_list[0] for e in ts_list):
                min_ts = min(ts_list)
                for chassis_id in self.frame_q.keys():
                    if self.frame_q[chassis_id] == min_ts:
                        #logging.debug("Dropping timestamp for startup sync")
                        self.frame_q[chassis_id] = None
                        self.frame_q_monitor[chassis_id][2].set()
                return out_data
            else:
                logging.info("Got startup sync %s" % ts_list)
                self.frames_syncd = True
                self.no_sync = False
        elif self.frame_reset_pending:
            if all(e == ts_list[0] for e in ts_list):
                self.frame_reset_pending = False
                self.sync_active = {}
                self.frames_syncd = True
                logging.info("Frames are syncd %s" % ts_list)
            else:
                for chassis_id, f in self.frame_q.items():
                    do_add = False
                    if chassis_id not in self.sync_active:
                        do_add = True
                    if do_add:
                        chassis_to_send.append(chassis_id)
        if self.frames_syncd:
            chassis_to_send = self.frame_q.keys()

        out_data_frames = {}
        if len(self.current_data_frames) > 0:
            out_data = {'timestamp': ts_list[0], 'data_frames': self.current_data_frames}
            self.current_data_frames = {}
        for chassis_id in chassis_to_send:
            self.frame_q[chassis_id] = None
            self.frame_q_monitor[chassis_id][2].set()
        return out_data

    def _read_data_queue_thread(self):
        out_list = []
        t1 = None
        iterations = 0
        with self.frame_ready_condition:
            while self.is_streaming:
                if t1 is None:
                    t1 = time.time()

                if self.frame_ready_condition.wait(timeout=0.1):
                    iterations += 1
                    out_data = self._build_frame()

                    if out_data:
                        self._report_data_available(out_data)
                    #else:
                    #    logging.info("NOTHING")
                    if time.time() - t1 >= 60.0:
                        logging.info("avg %d iterations/sec" % (int(iterations/60)))
                        iterations = 0
                        t1 = None
                else:
                    logging.info("TIMEOUT")

        logging.info("Exiting the read_data_queue thread!")

    def start(self):
        # Clear out any old stale data from the data queue
        for svc in self.active_services.values():
            svc.clear_data_queue()
        self.reset_frame_buffer()

        self.update_count = 1
        self.total_time = 0

        for svc in self.active_services.values():
            svc.start_streaming()

        self.stream_thread = threading.Thread(target=self._read_data_queue_thread)
        self.stream_thread.daemon = True
        self.stream_thread.start()
        self._check_data_frames()

    def stop(self):
        logging.info("network data source stop")
        for svc in self.active_services.values():
            svc.stop_streaming()
            with self.frame_q_lock:
                self._stop_frame_q_monitor(svc.chassis_id)
        self.is_streaming = False
        logging.info("Waiting on stream thread")
        if self.stream_thread and self.stream_thread.is_alive():
            self.stream_thread.join(timeout=5)
        logging.info("Stream thread stopped")
        logging.info("network data source stop done")

    def set_wave_off(self, chassis_id, sensor_id):
        name = self.get_chassis_name_from_id(chassis_id)
        if name not in self.active_services:
            logging.error(f"{name} is not a registered chassis, can not send wave command")
            return
        self.active_services[name].cmd_wave_off(sensor_list=[sensor_id, ])

    def set_wave_ramp(self, chassis_id, sensor_id, freq, amp):
        self.set_wave_off(chassis_id, sensor_id)
        name = self.get_chassis_name_from_id(chassis_id)
        if name not in self.active_services:
            logging.error(f"{name} is not a registered chassis, can not send wave command")
            return
        self.active_services[name].cmd_wave(sensor_list=[(sensor_id, proto.WaveMessage.WAVE_RAMP, amp, freq), ])

    def set_wave_sine(self, chassis_id, sensor_id, freq, amp):
        self.set_wave_off(chassis_id, sensor_id)
        name = self.get_chassis_name_from_id(chassis_id)
        if name not in self.active_services:
            logging.error(f"{name} is not a registered chassis, can not send wave command")
            return
        self.active_services[name].cmd_wave(sensor_list=[(sensor_id, proto.WaveMessage.WAVE_SINE, amp, freq), ])

    def set_closed_loop(self, is_on):
        self.closed_loop_expected = is_on
        self.waiting_on_closed_loop = True
        self.sync_num_chassis(len(self.active_services))
        for svc in self.active_services.values():
            svc.cmd_closed_loop(is_on)
        for d in self.discovered_devices.values():
            d['closed_loop'] = None

    def check_closed_loop(self):
        all_closed = True
        all_open = True
        if self.waiting_on_closed_loop and len(self.active_services) == len(self.chassis_name_to_id):
            with self.services_lock:
                for chassis_name in self.active_services.keys():
                    if chassis_name not in self.discovered_devices:
                        return
                    elif self.discovered_devices[chassis_name]['closed_loop'] is None:
                        return
                    elif not self.discovered_devices[chassis_name]['closed_loop']:
                        all_closed = False
                    elif self.discovered_devices[chassis_name]['closed_loop']:
                        all_open = False

                if all_closed and (self.closed_loop_expected is None or self.closed_loop_expected):
                    self._report_closed_loop(True)
                    self.closed_loop_expected = True
                    self.waiting_on_closed_loop = False
                elif all_open and (self.closed_loop_expected is None or not self.closed_loop_expected):
                    self._report_closed_loop(False)
                    self.closed_loop_expected = False
                    self.waiting_on_closed_loop = False

    def sync_num_chassis(self, num):
        qb = self.get_chassis_name_from_id(0)
        self.active_services[qb].cmd_sync_req(num)

    def all_chassis_running(self):
        return all([s == proto.StatusPacket.RUNNING for s in self.chassis_status.values()])

    def chassis_missing(self):
        return any([s == None for s in self.chassis_status.values()])

    def chassis_config_valid(self):
        for chassis_name,chassis_id in self.chassis_name_to_id.items():
            chassis_num = self.discovered_devices[chassis_name]['num']
            if chassis_id + 1 != chassis_num:
                logging.error(f"Chassis {chassis_name} ID of {chassis_id} does not correspond to num of {chassis_num}")
                return False
        return True

    def chassis_config_done(self):
        return all([self.chassis_mgr.get_chassis(n).have_system_config for n in self.chassis_name_to_id])

