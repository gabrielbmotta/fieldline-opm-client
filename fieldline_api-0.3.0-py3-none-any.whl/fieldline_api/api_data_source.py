import logging
import time
import threading

from pycore.network_data_source import NetworkDataSource
from pycore import net_protocol_pb2 as proto
from .fieldline_datatype import FieldLineDataType, FieldLineSensorStatusType, FieldLineConnectStatusType


class ApiDataSource(NetworkDataSource):
    def __init__(self, interfaces, prefix, counter_lock, counter, hardware_state):
        self.counter_lock = counter_lock
        self.counter = counter
        self.hardware_state = hardware_state
        super(ApiDataSource, self).__init__(interfaces, prefix, self.counter_lock, self.counter, self.hardware_state)
        self.t = None
        self.is_running = False
        self.chassis_mapping = {}
        self._zeroconf_name_to_chassis_name = {}
        self.services = {}
        self.chassis_id_counter = 0
        self.sensor_status_dict = {}

        self.on_next_callback = None
        self.on_error_callback = None
        self.on_completed_callback = None

        self.data_callback = None

        self.waiting_list = []
        self.sensor_dict = {}

    def set_callbacks(self, on_next=None, on_error=None, on_completed=None):
        self.on_next_callback = on_next
        self.on_error_callback = on_error
        self.on_completed_callback = on_completed

    def update_waiting_list(self, sensor_dict):
        if len(self.waiting_list):
            logging.warning("Waiting list is not empty")
        self.waiting_list = []
        for chassis_id,sensor_list in sensor_dict.items():
            for sensor_id in sensor_list:
                self.waiting_list.append((chassis_id, sensor_id))

    def remove_waiting(self, chassis_id, sensor_id):
        tup = (chassis_id, sensor_id)
        if tup in self.waiting_list:
            self.waiting_list.remove(tup)
            if len(self.waiting_list) == 0:
                if self.on_completed_callback is not None:
                    self.on_completed_callback()
                self.set_callbacks() # reset all the callbacks

    def send_logic_command(self, sensor_dict, cmd):
        self.update_waiting_list(sensor_dict)
        super().send_logic_command(sensor_dict, cmd)

    def load_sensors(self):
        while not self.chassis_config_done():
            time.sleep(0.5)
        sensors = self.get_sensors()
        ret = {}
        for s in sensors:
            if s.present:
                if s.chassis_id not in ret:
                    ret[s.chassis_id] = []
                ret[s.chassis_id].append(s.sensor_id)
        return ret

    def connect_to_devices(self, ip_list, timeout=5.0):
        chassis_dict = {}
        all_connected = True
        for i, ip in enumerate(ip_list):
            chassis_name = "%s:7777" % ip
            chassis_dict[chassis_name] = i
            connected = self.connect_req(ip, 7777)
            if not connected:
                raise ConnectionError("Unable to connect to chassis %s" % ip)
        self.connect_chassis_list(chassis_dict)
        ready = self.all_chassis_running()
        start_time = time.time()
        while not ready and timeout > 0 and time.time() - start_time < timeout:
            time.sleep(0.5)
            ready = self.all_chassis_running()
        if not ready:
            if self.chassis_missing():
                raise ConnectionError("Chassis missing")
            else:
                raise ConnectionError("Chassis not ready")
        elif not self.chassis_config_valid():
            raise ConnectionError("Invalid chassis config")

    def get_sensor_state(self, chassis_id, sensor_id):
        for s in self.get_sensors():
            if s.chassis_id == chassis_id and s.sensor_id == sensor_id:
                if s.get_color() == 9 and s.get_blink_state() == 1:
                    return FieldLineSensorStatusType.SENSOR_READY
                if s.get_color() == 6 and s.get_blink_state() == 1:
                    return FieldLineSensorStatusType.SENSOR_FINE_ZEROED
                elif s.get_color() == 6 and s.get_blink_state() == 2:
                    return FieldLineSensorStatusType.SENSOR_FINE_ZEROING
                elif s.get_color() == 5 and s.get_blink_state() == 1:
                    return FieldLineSensorStatusType.SENSOR_COARSE_ZEROED
                elif s.get_color() == 5 and s.get_blink_state() == 2:
                    return FieldLineSensorStatusType.SENSOR_COARSE_ZEROING
                elif s.get_blink_state() == 2:
                    return FieldLineSensorStatusType.SENSOR_RESTARTING
                elif s.get_color() == 4 and s.get_blink_state() == 1:
                    return FieldLineSensorStatusType.SENSOR_RESTARTED
                elif s.get_blink_state == 4:
                    return FieldLineSensorStatusType.SENSOR_ERROR
        return None

    # Override
    def update_state(self, msg=None):
        logging.info("update_state called")
        logging.info(f"{msg}")
        #print(msg)
        super().update_state(msg)
        if msg.chassis_name not in self.chassis_name_to_id:
            return
        msg_chassis_id = self.chassis_name_to_id[msg.chassis_name]
        if len(msg.sensor_state) > 0:
            #print("SENSOR_STATE %s" % msg)
            cmd_list = [proto.SensorState.RESTART_COMPLETE, proto.SensorState.COARSE_ZERO_COMPLETE, proto.SensorState.FINE_ZERO_COMPLETE]
            error_list = [proto.SensorState.ERROR, proto.SensorState.SOFT_ERROR]
            for sc in msg.sensor_state:
                if msg.chassis_name in self.chassis_name_to_id:
                    chassis_id = self.chassis_name_to_id[msg.chassis_name]
                    if sc.state in cmd_list:
                        if self.on_next_callback is not None:
                            self.on_next_callback(chassis_id, sc.sensor_id)
                        self.remove_waiting(chassis_id, sc.sensor_id)
                    elif sc.state in error_list:
                        error_code = None
                        if sc.HasField('error_flags'):
                            error_code = sc.error_flags
                        if self.on_error_callback is not None:
                            self.on_error_callback(chassis_id, sc.sensor_id, error_code)
                        self.remove_waiting(chassis_id, sc.sensor_id)

    def handle_chassis_added(self, chassis_name):
        if chassis_name in self.chassis_name_to_id:
            self.connect_chassis(chassis_name)

    # Override
    def handle_chassis_removed(self, chassis_name):
        logging.info("Chassis %s removed" % chassis_name)
        if chassis_name in self.chassis_name_to_id:
            del self.chassis_name_to_id[chassis_name]

    def is_service_running(self):
        return self.is_running

    # Override
    def start(self):
        self.is_streaming = True
        super().start()

    # Override
    def stop(self):
        self.is_streaming = False
        super().stop()

    def set_closed_loop(self, enabled):
        super().set_closed_loop(enabled)
        while self.waiting_on_closed_loop:
            time.sleep(0.1)

    def start_datatype(self, chassis_id, sensor_list, datatype, freq=1000):
        self.configure_datatype(chassis_id, sensor_list, datatype, freq)

    def stop_datatype(self, chassis_id, sensor_list, datatype):
        self.configure_datatype(chassis_id, sensor_list, datatype, 0)

    def configure_datatype(self, chassis_id, sensor_list, datatype, freq=1000):
        channel_configs = {datatype: (freq, 1.0)}
        chassis_name = None
        for c_name, c_id in self.chassis_name_to_id.items():
            if c_id == chassis_id:
                chassis_name = c_name
                break
        if chassis_name is not None:
            for s in sensor_list:
                self.configure_sensor_list(chassis_name, s, channel_configs)

    def start_adc(self, chassis_id, freq=1000):
        self.configure_datatype(chassis_id, [0], 0, freq)

    def stop_adc(self, chassis_id):
        self.configure_datatype(chassis_id, [0], 0, 0)

    def _report_data_available(self, sample):
        if self.data_callback is not None:
            self.data_callback(sample)

    def _handle_blink_state_changed(self, chassis_id, sensor_id, color, blink_state):
        pass

    def read_data(self, data_callback=None):
        self.data_callback = data_callback
